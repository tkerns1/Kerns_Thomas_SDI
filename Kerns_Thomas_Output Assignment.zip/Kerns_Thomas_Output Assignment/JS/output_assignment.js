/**
 * Thomas Kerns
 * SDI
 * 201503-02
 */

var shoeSize = 10.5; // number variable
var myClass = "SDI"; //string variable
var status = true;   // Boolean variable

console.log("Hello Class");
console.log("My shoe size is " + shoeSize + ".");
console.log("My current class is " + myClass + ".");
console.log(" It's " + status + " I had a problem with Github.");